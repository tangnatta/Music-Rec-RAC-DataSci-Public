
$(document).ready(function () {
    $('#submit').click(function () {
     addUser();
  });
    var content = "<i class='las la-caret-left'></i>"


                                              
                                            
	$('#relation1').html(content);
    $('#relation2').html(content);
    $('#relation3').html(content);
});
function addUser() {
    
}